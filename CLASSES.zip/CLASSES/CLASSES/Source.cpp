#include <iostream>
#include<ctime>
using namespace std;


int main()
{
	setlocale(LC_ALL, "ru");
	srand(time(NULL));
	int arr[20];
	for (int i = 0; i < 20; i++)
	{
		arr[i] = rand() % 10 +1;
	}

	cout << "������� ������" << endl;
	for (int i = 0; i < 20; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
	
	int maxIndex, minIndex;
	maxIndex = minIndex = 0;
	for (int i = 0; i < 20; i++)
	{
		if (arr[i]>arr[maxIndex])
		{
			maxIndex = i;
		}

		if (arr[i]<arr[minIndex])
		{
			minIndex = i;
		}
	}
	
	cout << endl << "Min = " << arr[minIndex] << " " << "Max = " << arr[maxIndex] << endl;
	int mult = 1;
	if (minIndex<maxIndex)
	{
		for (int i = minIndex; i <= maxIndex; i++)
		{
			mult = mult * arr[i];
		}
	}
	else
	{
		for (int i = maxIndex; i <= minIndex; i++)
		{
			mult = mult * arr[i];
		}
	}
	cout << "������������ = " << mult << endl;



	system("pause");
}